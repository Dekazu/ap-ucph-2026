-- | Omnibus test suite grouped by which task each test applies to.
module Tests (tests) where

import APL.AST
import APL.Eval
import APL.Monad
import APL.Parser
import BlockAutomaton.Rules
import BlockAutomaton.Server
import qualified BlockAutomaton.Simulation as Simulation
import Control.Monad
import Galapagos.Parser
import qualified Galapagos.Rules as Galapagos
import Test.QuickCheck
import Test.Tasty (TestTree, testGroup)
import Test.Tasty.HUnit (assertBool, assertFailure, testCase, (@?=))
import Test.Tasty.QuickCheck (testProperty)

parserTest :: String -> Exp -> TestTree
parserTest s e =
  testCase s $
    case parseAPL "input" s of
      Left err -> assertFailure err
      Right e' -> e' @?= e

parserTestFail :: String -> TestTree
parserTestFail s =
  testCase s $
    case parseAPL "input" s of
      Left _ -> pure ()
      Right e ->
        assertFailure $
          "Expected parse error but received this AST:\n" ++ show e

galapagosParserTest :: String -> Galapagos.Config -> TestTree
galapagosParserTest s e =
  testCase s $
    case parseGalapagos "input" s of
      Left err -> assertFailure err
      Right e' -> e' @?= e

galapagosParserTestFail :: String -> TestTree
galapagosParserTestFail s =
  testCase s $
    case parseGalapagos "input" s of
      Left _ -> pure ()
      Right e ->
        assertFailure $
          "Expected parse error but received this AST:\n" ++ show e

-- Definitions of finches corresponding to the strategies in the assignment
-- text. These may be useful for testing, but you do not have to use them.
invalid, cheater, samaritan, flipflop :: Galapagos.Finch
invalid =
  Galapagos.Finch
    { Galapagos.finchID = 0,
      Galapagos.finchHP = 10,
      Galapagos.finchRoundsLeft = 3,
      Galapagos.finchColour = Galapagos.RGB 0xff 0xff 0xff,
      Galapagos.finchStrategy =
        void $ eval mempty $ Galapagos.finchStrategyExp invalid,
      Galapagos.finchStrategyExp =
        CstBool False
    }
cheater =
  Galapagos.Finch
    { Galapagos.finchID = 0,
      Galapagos.finchHP = 10,
      Galapagos.finchRoundsLeft = 3,
      Galapagos.finchColour = Galapagos.RGB 0x00 0x00 0xff,
      Galapagos.finchStrategy =
        void $ eval mempty $ Galapagos.finchStrategyExp cheater,
      Galapagos.finchStrategyExp =
        ForLoop
          ("x", CstInt 0)
          ("i", CstInt 100)
          (Let "unused" Meet Ignore)
    }
samaritan =
  Galapagos.Finch
    { Galapagos.finchID = 0,
      Galapagos.finchHP = 20,
      Galapagos.finchRoundsLeft = 4,
      Galapagos.finchColour = Galapagos.RGB 0xff 0x00 0x00,
      Galapagos.finchStrategy =
        void $ eval mempty $ Galapagos.finchStrategyExp samaritan,
      Galapagos.finchStrategyExp =
        ForLoop
          ("x", CstInt 0)
          ("i", CstInt 100)
          (Let "unused" Meet Groom)
    }
flipflop =
  Galapagos.Finch
    { Galapagos.finchID = 0,
      Galapagos.finchHP = 20,
      Galapagos.finchRoundsLeft = 4,
      Galapagos.finchColour = Galapagos.RGB 0x00 0xff 0x00,
      Galapagos.finchStrategy =
        void $ eval mempty $ Galapagos.finchStrategyExp flipflop,
      Galapagos.finchStrategyExp =
        ForLoop
          ("x", CstInt 0)
          ("i", CstInt 100)
          (Let "unused" Meet (If (Eql (Mul (Div (Var "i") (CstInt 2)) (CstInt 2)) (Var "i")) Ignore Groom))
    }

defaultConfig :: Galapagos.Config
defaultConfig =
  Galapagos.Config
    { Galapagos.cfgHeight = 10,
      Galapagos.cfgWidth = 10,
      Galapagos.cfgParams = Galapagos.defaultParams,
      Galapagos.cfgStrategies =
        [ ( "samaritan",
            Galapagos.finchColour samaritan,
            Galapagos.finchStrategyExp samaritan
          ),
          ( "cheater",
            Galapagos.finchColour cheater,
            Galapagos.finchStrategyExp cheater
          ),
          ( "flipflop",
            Galapagos.finchColour flipflop,
            Galapagos.finchStrategyExp flipflop
          )
        ]
    }

-- This function runs a block automaton rule set for some number of iterations
-- using both the simulator and the server, then checks if they produce the same
-- result.
testEquivalence :: (Eq obs, Show obs) => Rules state obs -> Int -> IO ()
testEquivalence rules steps = do
  let h = 8
      w = 8
      simulated =
        Simulation.observeGrid rules $
          (!! steps) $
            iterate (Simulation.stepGrid rules) $
              Simulation.initialGrid rules h w
  s <- startAutomaton rules h w
  replicateM_ steps $ stepAutomaton s
  real <- observeAutomaton s
  real @?= simulated

taskAtests :: TestTree
taskAtests =
  testGroup
    "Task A"
    []

taskBtests :: TestTree
taskBtests =
  testGroup
    "Task B"
    []

taskCtests :: TestTree
taskCtests =
  testGroup
    "Task C"
    [ testCase "Smoothen(0)" $ testEquivalence smoothen 0,
      testCase "Smoothen(1)" $ testEquivalence smoothen 1,
      testCase "Smoothen(2)" $ testEquivalence smoothen 2
    ]

taskDtests :: TestTree
taskDtests =
  testGroup
    "Task D"
    []

taskEtests :: TestTree
taskEtests =
  testGroup
    "Task E"
    []

taskFtests :: TestTree
taskFtests =
  testGroup
    "Task F"
    []

tests :: TestTree
tests =
  testGroup
    "All tests"
    [ taskAtests,
      taskBtests,
      taskCtests,
      taskDtests,
      taskEtests,
      taskFtests
    ]
