module BlockAutomaton.Server
  ( Automaton,
    startAutomaton,
    stepAutomaton,
    observeAutomaton,
  )
where

import Data.List (zipWith4)
import BlockAutomaton.Rules
import Control.Concurrent
import Control.Monad (forM, forM_, replicateM, ap, liftM)
import GenServer

-- Messages sent to Main Server
data AutomatonMsg obs = 
  MsgTriggerStep
  | MsgObserve (ReplyChan [[obs]])

data Direction = DirUp | DirDown | DirLeft | DirRight

data Dimension = Horizontal | Vertical

data NeighborChannels state obs = NeighborChannels {
  topChan :: Chan (WorkerToWorkerMsg state obs),
  bottomChan :: Chan (WorkerToWorkerMsg state obs),
  leftChan :: Chan (WorkerToWorkerMsg state obs),
  rightChan :: Chan (WorkerToWorkerMsg state obs)
}

data CellStates state = CellStates {
  upperLeft :: state,
  upperRight :: state,
  lowerLeft :: state,
  lowerRight :: state
}

-- Messages sent from Main Server to BlockWorkers
data BlockWorkerMsg state obs = 
  MsgPerformStep Bool
  | MsgObserveBlock (ReplyChan (CellStates obs))

-- Messages sent between Workers (on worker-worker channels)
data WorkerToWorkerMsg state obs = MsgShiftBlock state state -- Direction (not really necessary, might be cleaner to include in msg? -> See later)

data Automaton obs = Automaton (Server (AutomatonMsg obs))

data BlockWorker state obs = BlockWorker (Server (BlockWorkerMsg state obs))

-- InternalServerState (ISS)
data ISS state obs = ISS {
  workers :: [[BlockWorker state obs]],
  currentStep :: Int
}

-- InternalBlockWorkerState (IBWS)
data IBWS state obs = IBWS {
  rules :: Rules state obs,
  cellStates :: CellStates state,
  inputChannels :: NeighborChannels state obs,
  outputChannels :: NeighborChannels state obs
}

------------------  Block Worker Monad --------------------

newtype BWM state obs a = BWM (IBWS state obs -> IO (a, IBWS state obs))

instance Functor (BWM state obs) where
  fmap = liftM

instance Applicative (BWM state obs) where
  pure x = BWM $ \state -> pure (x, state)
  (<*>) = ap

instance Monad (BWM state obs) where
  BWM m >>= f = BWM $ \state -> do
    (x, state') <- m state
    let BWM f' = f x
    f' state'

get :: BWM state obs (IBWS state obs)
get = BWM $ \state -> pure (state, state)

put :: IBWS state obs -> BWM state obs ()
put state = BWM $ \_ -> pure ((), state)

modify :: (IBWS state obs -> IBWS state obs) -> BWM state obs ()
modify f = do
  state <- get
  put $ f state

io :: IO a -> BWM state obs a
io m = BWM $ \state -> do
  x <- m
  pure (x, state)

runBWM :: IBWS state obs -> BWM state obs a -> IO a
runBWM state (BWM f) = fst <$> f state

-------------------- End BWM Monad ------------------------

-------------------- Utility Functions --------------------

-- take the last element and put it at the front
rotateForward :: [a] -> [a]
rotateForward [] = []
rotateForward xs = last xs : init xs 

-- take the first element and put it at the end
rotateBack :: [a] -> [a]
rotateBack [] = []
rotateBack (x : xs) = xs ++ [x]

rotateRight :: [[a]] -> [[a]] -- map rotateForward on each row of the grid
rotateRight xs = map rotateForward xs

rotateLeft :: [[a]] -> [[a]] -- map rotateBack on each row of the grid
rotateLeft xs = map rotateBack xs


getShiftDirection :: Bool -> Dimension -> Direction
getShiftDirection isEven Horizontal = if isEven then DirLeft else DirRight
getShiftDirection isEven Vertical = if isEven then DirUp else DirDown

invertDirection :: Direction -> Direction
invertDirection DirUp = DirDown
invertDirection DirDown = DirUp
invertDirection DirLeft = DirRight
invertDirection DirRight = DirLeft

getInputChannel :: Direction -> IBWS state obs -> Chan (WorkerToWorkerMsg state obs)
getInputChannel DirUp ibws = topChan (inputChannels ibws)
getInputChannel DirDown ibws = bottomChan (inputChannels ibws)
getInputChannel DirLeft ibws = leftChan (inputChannels ibws)
getInputChannel DirRight ibws = rightChan (inputChannels ibws)

getOutputChannel :: Direction -> IBWS state obs -> Chan (WorkerToWorkerMsg state obs)
getOutputChannel DirUp ibws = topChan (outputChannels ibws)
getOutputChannel DirDown ibws = bottomChan (outputChannels ibws)
getOutputChannel DirLeft ibws = leftChan (outputChannels ibws)
getOutputChannel DirRight ibws = rightChan (outputChannels ibws)

------------------ End Utility Functions -------------------

------------------ Main Server -------------------

broadcast :: ISS state obs -> BlockWorkerMsg state obs -> IO ()
broadcast iss msg = do
  forM_ (workers iss) $ \workerRow -> do
    forM_ workerRow $ \(BlockWorker server) -> do
      sendTo server msg

serverMsgLoop :: ISS state obs -> Chan (AutomatonMsg obs) -> IO ()
serverMsgLoop iss chan = do
  msg <- receive chan
  case msg of
    MsgTriggerStep -> do
      broadcast iss (MsgPerformStep (even (currentStep iss)))
      serverMsgLoop (iss { currentStep = currentStep iss + 1 }) chan

    MsgObserve replyChan -> do
      obsGrid <- forM (workers iss) $ \workerRow -> do
        forM workerRow $ \(BlockWorker worker) -> do
          requestReply worker MsgObserveBlock
      -- transform grid of blocks (each including 4 cells) into grid of cells
      let foldBlockRow blockRow = foldr (\(CellStates ul ur ll lr) (upper, lower) -> (ul:ur:upper, ll:lr:lower)) ([], []) blockRow
          obsRowPairs = map foldBlockRow obsGrid
          obsRows = concatMap (\(upper, lower) -> [upper, lower]) obsRowPairs

      if odd (currentStep iss)
        then
          reply replyChan $ rotateForward (rotateRight obsRows)
        else
          reply replyChan obsRows
      
      serverMsgLoop iss chan

------------------ End Main Server -------------------

------------------ BlockWorker -------------------

sendShift :: Direction -> BWM state obs ()
sendShift dir = do
  ibws <- get
  let outputChan = getOutputChannel dir ibws
      (stateA, stateB) = case dir of
        DirUp -> (upperLeft (cellStates ibws), upperRight (cellStates ibws))
        DirDown -> (lowerLeft (cellStates ibws), lowerRight (cellStates ibws))
        DirLeft -> (upperLeft (cellStates ibws), lowerLeft (cellStates ibws))
        DirRight -> (upperRight (cellStates ibws), lowerRight (cellStates ibws))
  io $ send outputChan (MsgShiftBlock stateA stateB)

receiveShift :: Direction -> BWM state obs ()
receiveShift dir = do
  ibws <- get
  MsgShiftBlock stateA stateB <- io $ receive (getInputChannel dir ibws)
  let cS' = case dir of
        DirUp -> (cellStates ibws) { 
          lowerLeft = upperLeft (cellStates ibws), lowerRight = upperRight (cellStates ibws),
          upperLeft = stateA, upperRight = stateB 
        }
        DirDown -> (cellStates ibws) { 
          upperLeft = lowerLeft (cellStates ibws), upperRight = lowerRight (cellStates ibws),
          lowerLeft = stateA, lowerRight = stateB 
        }
        DirLeft -> (cellStates ibws) { 
          upperRight = upperLeft (cellStates ibws), lowerRight = lowerLeft (cellStates ibws),
          upperLeft = stateA, lowerLeft = stateB 
        }
        DirRight -> (cellStates ibws) { 
          upperLeft = upperRight (cellStates ibws), lowerLeft = lowerRight (cellStates ibws),
          upperRight = stateA, lowerRight = stateB 
        }
  put ibws { cellStates = cS' }
  

cellShift :: Bool -> Dimension -> BWM state obs ()
cellShift isEven dim = do
  sendShift (getShiftDirection isEven dim)
  receiveShift (invertDirection (getShiftDirection isEven dim))

performInteractions :: BWM state obs ()
performInteractions = do
  modify $ \ibws -> 
    let r = rules ibws
        cS = cellStates ibws
        (ul', ur') = rulesInteract r (upperLeft cS, upperRight cS)
        (ll', lr') = rulesInteract r (lowerLeft cS, lowerRight cS)
        (ul'', ll'') = rulesInteract r (ul', ll')
        (ur'', lr'') = rulesInteract r (ur', lr')
    in ibws { cellStates = CellStates {
        upperLeft = ul'',
        upperRight = ur'',
        lowerLeft = ll'',
        lowerRight = lr''
      } }

bwMainMsgLoop :: Chan (BlockWorkerMsg state obs) -> BWM state obs ()
bwMainMsgLoop chan = do
  msg <- io $ receive chan
  case msg of
    MsgPerformStep isEven -> do
      performInteractions
      cellShift isEven Horizontal
      cellShift isEven Vertical
      bwMainMsgLoop chan
    MsgObserveBlock replyChan -> do
      ibws <- get
      let cS = cellStates ibws
          obsCSts = CellStates {
            upperLeft = rulesObserve (rules ibws) (upperLeft cS),
            upperRight = rulesObserve (rules ibws) (upperRight cS),
            lowerLeft = rulesObserve (rules ibws) (lowerLeft cS),
            lowerRight = rulesObserve (rules ibws) (lowerRight cS)
          }
      io $ reply replyChan obsCSts
      bwMainMsgLoop chan
    

-- Initializes the internal state and starts the main message loop
bwEntryPoint :: Rules state obs -> (Int, Int) -> NeighborChannels state obs  -> NeighborChannels state obs -> Chan (BlockWorkerMsg state obs) -> IO ()
bwEntryPoint r (i, j) iC oC mainChan = runBWM ibws (bwMainMsgLoop mainChan)
  where
    cS = CellStates {
      upperLeft = rulesInitial r (i, j),
      upperRight = rulesInitial r (i, j + 1),
      lowerLeft = rulesInitial r (i + 1, j),
      lowerRight = rulesInitial r (i + 1, j + 1)
    }
    ibws = IBWS {
      rules = r,
      cellStates = cS,
      inputChannels = iC,
      outputChannels = oC
    }

------------------ End BlockWorker -------------------


zipRow :: [Chan (WorkerToWorkerMsg state obs)] 
        -> [Chan (WorkerToWorkerMsg state obs)] 
        -> [Chan (WorkerToWorkerMsg state obs)] 
        -> [Chan (WorkerToWorkerMsg state obs)] 
        -> [NeighborChannels state obs]
zipRow = zipWith4 (\t b l r -> NeighborChannels {
    topChan = t,
    bottomChan = b,
    leftChan = l,
    rightChan = r
  })

zipChannels :: [[Chan (WorkerToWorkerMsg state obs)]] 
             -> [[Chan (WorkerToWorkerMsg state obs)]] 
             -> [[Chan (WorkerToWorkerMsg state obs)]] 
             -> [[Chan (WorkerToWorkerMsg state obs)]] 
             -> [[NeighborChannels state obs]]
zipChannels t b l r = zipWith4 zipRow t b l r


initializeChannels :: Int -> Int -> IO [[(NeighborChannels state obs, NeighborChannels state obs)]]
initializeChannels numBlockRows numBlockCols = do
  topInputs <- replicateM numBlockRows $ replicateM numBlockCols newChan
  bottomInputs <- replicateM numBlockRows $ replicateM numBlockCols newChan
  leftInputs <- replicateM numBlockRows $ replicateM numBlockCols newChan
  rightInputs <- replicateM numBlockRows $ replicateM numBlockCols newChan

  let topOutputs = rotateForward bottomInputs
      bottomOutputs = rotateBack topInputs
      leftOutputs = rotateRight rightInputs
      rightOutputs = rotateLeft leftInputs

      inputChans = zipChannels topInputs bottomInputs leftInputs rightInputs
      outputChans = zipChannels topOutputs bottomOutputs leftOutputs rightOutputs

  pure $ zipWith (zipWith (\i o -> (i, o))) inputChans outputChans

initializeBlockWorkers :: Rules state obs 
                       -> [[(NeighborChannels state obs, NeighborChannels state obs)]] 
                       -> IO [[BlockWorker state obs]]
initializeBlockWorkers r channelMatrix = do
  forM (zip [0..] channelMatrix) $ \(rowIdx, row) -> do
    forM (zip [0..] row) $ \(colIdx, (iC, oC)) -> do
      BlockWorker <$> spawn (bwEntryPoint r (rowIdx * 2, colIdx * 2) iC oC)

startAutomaton :: Rules state obs -> Int -> Int -> IO (Automaton obs)
startAutomaton r height width = 
  let dimensionsValid = even height && height >= 0 && even width && width >= 0
      numBlockRows = height `div` 2
      numBlockCols = width `div` 2
      iss = ISS { workers = [], currentStep = 0 }
  in if dimensionsValid
      then do
        channelMatrix <- initializeChannels numBlockRows numBlockCols
        workersList <- initializeBlockWorkers r channelMatrix
        mainServer <- spawn $ serverMsgLoop (iss { workers = workersList })
        pure $ Automaton mainServer
      else
        error "Height and Width must be positive multiples of 2"


stepAutomaton :: Automaton obs -> IO ()
stepAutomaton (Automaton mainServer) = sendTo mainServer MsgTriggerStep

observeAutomaton :: Automaton obs -> IO [[obs]]
observeAutomaton (Automaton mainServer) = requestReply mainServer MsgObserve
