module Galapagos.Parser (parseGalapagos) where

import APL.AST
import APL.Parser (pExp)
import Control.Monad (void)
import Data.Char (isAlphaNum, isDigit, isHexDigit, digitToInt)
import Data.Void (Void)
import Galapagos.Rules
import Text.Megaparsec
import Text.Megaparsec.Char

type Parser = Parsec Void String

parseGalapagos :: FilePath -> String -> Either String Config
parseGalapagos fname s = case parse (space *> pConfig <* eof) fname s of
  Left err -> Left $ errorBundlePretty err
  Right x -> Right x


keywords :: [String]
keywords =
  [ 
    "height",
    "width",
    "startHP",
    "invReproductionChance",
    "maxHP",
    "lifespan",
    "invDensity",
    "payoffs",
    "strategy"
  ]

lexeme :: Parser a -> Parser a
lexeme p = p <* space

lSignedInt :: Parser Int
lSignedInt = lexeme $ do
  sign <- optional (char '-')
  digits <- some (satisfy isDigit)
  notFollowedBy (satisfy isAlphaNum)
  case sign of
    Just _  -> pure $ - (read digits)
    Nothing -> pure $ read digits

lString :: String -> Parser ()
lString s = lexeme $ void $ chunk s

lKeyword :: String -> Parser ()
lKeyword s = lexeme $ void $ try $ chunk s <* notFollowedBy (satisfy isAlphaNum)


pIntConfigElem :: String -> Parser Int
pIntConfigElem key = do
  lKeyword key
  lString "="
  lSignedInt

pSize :: Parser (Int, Int)
pSize = choice [
  do
    w <- pIntConfigElem "width"
    h <- pIntConfigElem "height"
    pure (w, h),
  do
    h <- pIntConfigElem "height"
    w <- pIntConfigElem "width"
    pure (w, h)
  ]

pParam :: Params -> Parser Params
pParam p = choice [
  do
    sHP <- pIntConfigElem "startHP"
    pure p { startHP = sHP },
  do
    iRC <- pIntConfigElem "invReproductionChance"
    pure p { invReproductionChance = iRC },
  do
    mHP <- pIntConfigElem "maxHP"
    pure p { maxHP = mHP },
  do
    ls <- pIntConfigElem "lifespan"
    pure p { lifespan = ls },
  do
    iD <- pIntConfigElem "invDensity"
    pure p { invDensity = iD },
  do
    lKeyword "payoffs"
    lString "="
    lString "("
    a <- lSignedInt
    lString ","
    b <- lSignedInt
    lString ","
    c <- lSignedInt
    lString ","
    d <- lSignedInt
    lString ")"
    pure p { payoffs = (a, b, c, d) }
  ]


pParams :: Params -> Parser Params
pParams p = choice [
  do
    p' <- pParam p
    pParams p',
  pure p
  ] 

isValidNameChar :: Char -> Bool
isValidNameChar c = isAlphaNum c || c == '_' || c == '-' || c == '.'

lName :: Parser VName
lName = lexeme $ try $ do
  v <- some $ satisfy isValidNameChar
  if v `elem` keywords
    then fail "Unexpected keyword"
    else pure v


hexPairToInt :: Char -> Char -> Int
hexPairToInt h1 h2 = (16 * digitToInt h1) + digitToInt h2

lColor :: Parser Colour
lColor = lexeme $ try $ do
  lString "#"
  r1 <- satisfy isHexDigit
  r2 <- satisfy isHexDigit
  g1 <- satisfy isHexDigit
  g2 <- satisfy isHexDigit
  b1 <- satisfy isHexDigit
  b2 <- satisfy isHexDigit
  pure $ RGB (hexPairToInt r1 r2) (hexPairToInt g1 g2) (hexPairToInt b1 b2)

pStrategy :: Parser (Name, Colour, Exp)
pStrategy = do
  lKeyword "strategy"
  name <- lName
  color <- lColor
  lString "{"
  strategyExp <- pExp
  lString "}"
  pure (name, color, strategyExp)


pStrategies :: [(Name, Colour, Exp)] -> Parser [(Name, Colour, Exp)]
pStrategies strategies = choice [
  do
    strategy <- pStrategy
    pStrategies (strategy : strategies),
  pure strategies
  ] 

pConfig :: Parser Config
pConfig = do
  (width, height) <- pSize
  params <- pParams defaultParams
  strategies <- pStrategies []
  pure Config { cfgHeight = height, cfgWidth = width, cfgParams = params, cfgStrategies = strategies }