module Galapagos.Rules
  ( galapagos,
    Colour (..),
    Name,
    Strategy,
    Strategies,
    Config (..),
    Params (..),
    defaultParams,

    -- * For testing
    HP,
    Rounds,
    Finch (..),
    CellState (..),
    initial,
    reproduce,
    groom,
    age,
    kill,
    meet,
  )
where

import APL.AST (Exp)
import APL.Eval
import APL.Monad (EvalM, EvalOp (..), FinchID, Free (..))
import BlockAutomaton.Rules
import System.Random (StdGen, mkStdGen, uniform, uniformR)
import Control.Monad (void)
import Data.Tuple (swap)
import Prelude hiding (interact)

type HP = Int

type Rounds = Int

type Strategy = EvalM ()

type Name = String

-- | The colour represented as the red, green, and blue channels.
data Colour = RGB Int Int Int deriving (Show, Eq)

type Strategies = [(Name, Colour, Exp)]

-- Parameters for the world simulation.
data Params = Params
  { -- The starting hit points of a new finch.
    startHP :: HP,
    -- The inverse of the reproduction chance, i.e., to reproduce you must roll
    -- a 1 on a dice with this many sides.
    invReproductionChance :: Int,
    -- The maximum health points a finch can accumulate.
    maxHP :: HP,
    -- The lifespan of a new finch.
    lifespan :: Rounds,
    -- The inverse of the chance for a cell to be initially populated, i.e., a cell is populated if it rolls a 1 on a dice with this many sides.
    invDensity :: Int,
    -- The three payoff parameters:
    --   a. the payoff of both finches grooming.
    --   b. the payoff of both finches ignoring.
    --   c. the payoff of being groomed but ignoring.
    --   d. the payoff of being ignored but grooming.
    payoffs :: (Int, Int, Int, Int)
  }
  deriving (Eq, Show)

defaultParams :: Params
defaultParams =
  Params
    { startHP = 14,
      invReproductionChance = 6,
      maxHP = 40,
      lifespan = 23,
      invDensity = 4,
      payoffs = (1, -2, 3, -4)
    }

-- Helper function for computing the payoff based on groom/ignore decisions
-- (represneted as True/False respectively).
payoff :: Params -> Bool -> Bool -> (Int, Int)
payoff (Params {payoffs = (a, b, c, d)}) = f
  where
    f True True = (a, a)
    f False False = (b, b)
    f True False = (d, c)
    f False True = (c, d)

data Finch = Finch
  { finchID :: Int,
    finchHP :: HP,
    finchRoundsLeft :: Rounds,
    -- The colour is used for visualisation, but has no semantic significance.
    finchColour :: Colour,
    -- The current strategy.
    finchStrategy :: Strategy,
    -- The expression that is evaluated to produce the strategy.
    finchStrategyExp :: Exp
  }

-- A cell contains a random number generator and may also contain a finch.
data CellState = CellState
  { cellFinch :: Maybe Finch,
    cellRNG :: StdGen
  }

-- The first 'Int' is the 's' parameter for seeding the RNG.
initial :: Int -> Config -> (Int, Int) -> CellState
initial s cfg (i, j) = 
  let rng = mkStdGen (s + i * 10000 + j)
      (rn, rng') = uniformR (1, invDensity (cfgParams cfg)) rng
  in if rn == 1
      then
        let strategyIndex = (i+j) `mod` length (cfgStrategies cfg)
            (_name, colour, sExp) = cfgStrategies cfg !! strategyIndex
            (fID, rng'') = uniform rng'
            strategy = void $ eval envEmpty sExp
            finch = Finch
              { finchID = fID,
                finchHP = startHP (cfgParams cfg),
                finchRoundsLeft = lifespan (cfgParams cfg),
                finchColour = colour,
                finchStrategy = strategy,
                finchStrategyExp = sExp
              }
        in CellState { cellFinch = Just finch, cellRNG = rng'' }
      else CellState { cellFinch = Nothing, cellRNG = rng' }


createChildFinch :: Params -> Finch -> StdGen -> CellState
createChildFinch p parent rng =
  let (fID, rng') = uniform rng
      strategy = void $ eval envEmpty (finchStrategyExp parent)
      childFinch = Finch
        { finchID = fID,
          finchHP = startHP p,
          finchRoundsLeft = lifespan p,
          finchColour = finchColour parent,
          finchStrategy = strategy,
          finchStrategyExp = finchStrategyExp parent
        }
  in CellState { cellFinch = Just childFinch, cellRNG = rng' }

-- returns (parentCell, childCell)
tryReproduce :: Params -> Finch -> StdGen -> StdGen -> (CellState, CellState)
tryReproduce p parent parentRng emptyCellRng =
  let (roll, rng') = uniformR (1, invReproductionChance p) parentRng
  in if roll == 1
      then 
        ( CellState { cellFinch = Just parent, cellRNG = rng' },
          createChildFinch p parent emptyCellRng )
      else
        ( CellState { cellFinch = Just parent, cellRNG = rng' },
          CellState { cellFinch = Nothing, cellRNG = emptyCellRng } )

reproduce :: Params -> (CellState, CellState) -> (CellState, CellState)
reproduce p (cellA, cellB) = case (cellFinch cellA, cellFinch cellB) of
  (Just finchA, Nothing) -> tryReproduce p finchA (cellRNG cellA) (cellRNG cellB)
  (Nothing, Just finchB) -> swap (tryReproduce p finchB (cellRNG cellB) (cellRNG cellA))
  (_, _) -> (cellA, cellB)


runMeet :: Strategy -> FinchID -> Maybe Strategy
runMeet (Free (MeetOp k)) finchId = Just $ k finchId
runMeet _ _ = Nothing


updateFinches :: Params -> (Bool -> Strategy) -> (Bool -> Strategy) -> (Bool, Bool) -> (Finch, Finch) -> (Maybe Finch, Maybe Finch)
updateFinches p kA kB (doesGroomA, doesGroomB) (finchA, finchB) =
  let newStrategyA = kA doesGroomB
      newStrategyB = kB doesGroomA
      (payoffA, payoffB) = payoff p doesGroomA doesGroomB
      (newFinchHPA, newFinchHPB) = (min (finchHP finchA + payoffA) (maxHP p), 
                                    min (finchHP finchB + payoffB) (maxHP p))
  in (Just finchA { finchStrategy = newStrategyA, finchHP = newFinchHPA },
      Just finchB { finchStrategy = newStrategyB, finchHP = newFinchHPB } )

meet :: Params -> (Finch, Finch) -> (Maybe Finch, Maybe Finch)
meet p (finchA, finchB) = 
  let behaviorA = runMeet (finchStrategy finchA) (finchID finchB)
      behaviorB = runMeet (finchStrategy finchB) (finchID finchA)
  in case (behaviorA, behaviorB) of
    -- both valid
    (Just (Free (GroomOp kA)), Just (Free (GroomOp kB))) -> updateFinches p kA kB (True, True) (finchA, finchB)
    (Just (Free (GroomOp kA)), Just (Free (IgnoreOp kB))) -> updateFinches p kA kB (True, False) (finchA, finchB)
    (Just (Free (IgnoreOp kA)), Just (Free (GroomOp kB))) -> updateFinches p kA kB (False, True) (finchA, finchB)
    (Just (Free (IgnoreOp kA)), Just (Free (IgnoreOp kB))) -> updateFinches p kA kB (False, False) (finchA, finchB)
    -- one valid
    (Just (Free (GroomOp _)), _) -> (Just finchA, Nothing)
    (Just (Free (IgnoreOp _)), _) -> (Just finchA, Nothing)
    (_, Just (Free (GroomOp _))) -> (Nothing, Just finchB)
    (_, Just (Free (IgnoreOp _))) -> (Nothing, Just finchB)
    -- every valid case is handled above, everything else is invalid behavior from both sides
    (_, _) -> (Nothing, Nothing)



groom :: Params -> (CellState, CellState) -> (CellState, CellState)
groom p (cellA, cellB) = case (cellFinch cellA, cellFinch cellB) of
  (Just finchA, Just finchB) ->
    let (mFinchA', mFinchB') = meet p (finchA, finchB)
    in ( cellA { cellFinch = mFinchA' },
         cellB { cellFinch = mFinchB' } )
  (_, _) -> (cellA, cellB)

age :: CellState -> CellState
age cell = case cellFinch cell of
  Just finch -> cell { cellFinch = Just finch { finchRoundsLeft = finchRoundsLeft finch - 1 } }
  Nothing -> cell

kill :: CellState -> CellState
kill cell = case cellFinch cell of
  Just finch ->
    if finchHP finch <= 0 || finchRoundsLeft finch <= 0
      then cell { cellFinch = Nothing }
      else cell
  Nothing -> cell

both :: (a -> b) -> (a, a) -> (b, b)
both f (x, y) = (f x, f y)

interact :: Params -> (CellState, CellState) -> (CellState, CellState)
interact params =
  both kill
    . both age
    . groom params
    . reproduce params

observe :: CellState -> Colour
observe cell = case cellFinch cell of
  Nothing -> black
  Just finch -> finchColour finch
  where
    black = RGB 0 0 0

data Config = Config
  { cfgHeight :: Int,
    cfgWidth :: Int,
    cfgParams :: Params,
    cfgStrategies :: [(Name, Colour, Exp)]
  }
  deriving (Eq, Show)

galapagos :: Int -> Config -> Rules CellState Colour
galapagos seed cfg =
  Rules
    { rulesInitial = initial seed cfg,
      rulesInteract = interact $ cfgParams cfg,
      rulesObserve = observe
    }
