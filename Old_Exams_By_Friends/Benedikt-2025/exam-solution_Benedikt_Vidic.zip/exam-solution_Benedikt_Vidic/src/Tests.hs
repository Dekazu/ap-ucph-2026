-- | Omnibus test suite grouped by which task each test applies to.
module Tests (tests) where

import APL.AST
import APL.Eval
import APL.Monad
import APL.Parser
import BlockAutomaton.Rules
import BlockAutomaton.Server
import qualified BlockAutomaton.Simulation as Simulation
import Control.Monad
import Galapagos.Parser
import qualified Galapagos.Rules as Galapagos
import Test.QuickCheck
import Test.Tasty (TestTree, testGroup)
import Test.Tasty.HUnit (assertFailure, testCase, (@?=))
import Test.Tasty.QuickCheck ()


parserTest :: String -> Exp -> TestTree
parserTest s e =
  testCase s $
    case parseAPL "input" s of
      Left err -> assertFailure err
      Right e' -> e' @?= e

parserTestFail :: String -> TestTree
parserTestFail s =
  testCase s $
    case parseAPL "input" s of
      Left _ -> pure ()
      Right e ->
        assertFailure $
          "Expected parse error but received this AST:\n" ++ show e

galapagosParserTest :: String -> Galapagos.Config -> TestTree
galapagosParserTest s e =
  testCase s $
    case parseGalapagos "input" s of
      Left err -> assertFailure err
      Right e' -> e' @?= e

galapagosParserTestFail :: String -> TestTree
galapagosParserTestFail s =
  testCase s $
    case parseGalapagos "input" s of
      Left _ -> pure ()
      Right e ->
        assertFailure $
          "Expected parse error but received this AST:\n" ++ show e

-- Definitions of finches corresponding to the strategies in the assignment
-- text. These may be useful for testing, but you do not have to use them.
invalid, invalidInteraction, cheater, samaritan, flipflop :: Galapagos.Finch
invalid =
  Galapagos.Finch
    { Galapagos.finchID = 0,
      Galapagos.finchHP = 10,
      Galapagos.finchRoundsLeft = 3,
      Galapagos.finchColour = Galapagos.RGB 0xff 0xff 0xff,
      Galapagos.finchStrategy =
        void $ eval mempty $ Galapagos.finchStrategyExp invalid,
      Galapagos.finchStrategyExp =
        CstBool False
    }
invalidInteraction =
  Galapagos.Finch
    { Galapagos.finchID = 0,
      Galapagos.finchHP = 10,
      Galapagos.finchRoundsLeft = 3,
      Galapagos.finchColour = Galapagos.RGB 0xff 0xff 0xff,
      Galapagos.finchStrategy =
        void $ eval mempty $ Galapagos.finchStrategyExp invalid,
      Galapagos.finchStrategyExp =
        ForLoop
          ("x", CstInt 0)
          ("i", CstInt 100)
          (Let "unused" Meet (CstBool False))
    }
cheater =
  Galapagos.Finch
    { Galapagos.finchID = 0,
      Galapagos.finchHP = 10,
      Galapagos.finchRoundsLeft = 3,
      Galapagos.finchColour = Galapagos.RGB 0x00 0x00 0xff,
      Galapagos.finchStrategy =
        void $ eval mempty $ Galapagos.finchStrategyExp cheater,
      Galapagos.finchStrategyExp =
        ForLoop
          ("x", CstInt 0)
          ("i", CstInt 100)
          (Let "unused" Meet Ignore)
    }
samaritan =
  Galapagos.Finch
    { Galapagos.finchID = 0,
      Galapagos.finchHP = 20,
      Galapagos.finchRoundsLeft = 4,
      Galapagos.finchColour = Galapagos.RGB 0xff 0x00 0x00,
      Galapagos.finchStrategy =
        void $ eval mempty $ Galapagos.finchStrategyExp samaritan,
      Galapagos.finchStrategyExp =
        ForLoop
          ("x", CstInt 0)
          ("i", CstInt 100)
          (Let "unused" Meet Groom)
    }
flipflop =
  Galapagos.Finch
    { Galapagos.finchID = 0,
      Galapagos.finchHP = 20,
      Galapagos.finchRoundsLeft = 4,
      Galapagos.finchColour = Galapagos.RGB 0x00 0xff 0x00,
      Galapagos.finchStrategy =
        void $ eval mempty $ Galapagos.finchStrategyExp flipflop,
      Galapagos.finchStrategyExp =
        ForLoop
          ("x", CstInt 0)
          ("i", CstInt 100)
          (Let "unused" Meet (If (Eql (Mul (Div (Var "i") (CstInt 2)) (CstInt 2)) (Var "i")) Ignore Groom))
    }

defaultConfig :: Galapagos.Config
defaultConfig =
  Galapagos.Config
    { Galapagos.cfgHeight = 10,
      Galapagos.cfgWidth = 10,
      Galapagos.cfgParams = Galapagos.defaultParams,
      Galapagos.cfgStrategies =
        [ ( "samaritan",
            Galapagos.finchColour samaritan,
            Galapagos.finchStrategyExp samaritan
          ),
          ( "cheater",
            Galapagos.finchColour cheater,
            Galapagos.finchStrategyExp cheater
          ),
          ( "flipflop",
            Galapagos.finchColour flipflop,
            Galapagos.finchStrategyExp flipflop
          )
        ]
    }

-- This function runs a block automaton rule set for some number of iterations
-- using both the simulator and the server, then checks if they produce the same
-- result.
testEquivalence :: (Eq obs, Show obs) => Rules state obs -> Int -> IO ()
testEquivalence rules steps = do
  let h = 8
      w = 8
      simulated =
        Simulation.observeGrid rules $
          (!! steps) $
            iterate (Simulation.stepGrid rules) $
              Simulation.initialGrid rules h w
  s <- startAutomaton rules h w
  replicateM_ steps $ stepAutomaton s
  real <- observeAutomaton s
  real @?= simulated

-- Helper function to evaluate an expression and extract the result or error
testEval :: Exp -> Either Error Val
testEval e1 = interpretEval (eval envEmpty e1)
  where
    interpretEval :: EvalM a -> Either Error a
    interpretEval (Pure x) = Right x
    interpretEval (Free (ErrorOp e)) = Left e
    interpretEval _ = Left "Error, not implemented. This case is not relevant for the tests regarding task A"
    
isLeft :: Either a b -> Bool
isLeft (Left _) = True
isLeft _      = False

taskAtests :: TestTree
taskAtests =
  testGroup
    "Task A"
    [
      testGroup "Set" [
        testCase "Basic set construction" $
          testEval (Set [CstInt 1, CstInt 2, CstInt 3]) @?= Right (ValSet [ValInt 1, ValInt 2, ValInt 3]),
        testCase "Set with duplicates" $
          testEval (Set [CstInt 1, CstInt 2, CstInt 2, CstInt 3, CstInt 1]) @?= Right (ValSet [ValInt 1, ValInt 2, ValInt 3]),
        testCase "Empty set" $
          testEval (Set []) @?= Right (ValSet []),
        testCase "Set with various types of Vals (including nested sets)" $
          testEval (Set [CstInt 1, CstBool True, Set [CstInt 2, CstInt 3]]) @?= Right (ValSet [ValInt 1, ValBool True, ValSet [ValInt 2, ValInt 3]]),
        testCase "Set with non-values" $
          isLeft (testEval (Set [CstInt 1, Var "x"])) @?= True,
        testCase "Set with multiple errors, expect first to be thrown" $
          testEval (Set [CstInt 1, Div (CstInt 1) (CstInt 0), Var "x"]) @?= Left "Division by zero", -- explicit test for error message to check order
        testCase "Set Equality is order-independent" $
          testEval (Eql (Set [CstInt 1, CstInt 2, CstInt 3]) (Set [CstInt 2, CstInt 1, CstInt 3])) @?= Right (ValBool True)
      ],
      testGroup "Union" [
        testCase "Basic union of disjoint sets" $
          testEval (Union (Set [CstInt 1, CstInt 2]) (Set [CstInt 3, CstInt 4])) @?= Right (ValSet [ValInt 1, ValInt 2, ValInt 3, ValInt 4]),
        testCase "Union of overlapping sets" $
          testEval (Union (Set [CstInt 1, CstInt 2]) (Set [CstInt 2, CstInt 3])) @?= Right (ValSet [ValInt 1, ValInt 2, ValInt 3]),
        testCase "Union of identical sets" $
          testEval (Union (Set [CstInt 1, CstInt 2]) (Set [CstInt 1, CstInt 2])) @?= Right (ValSet [ValInt 1, ValInt 2]),
        testCase "Union where one operand is not a set" $
          isLeft (testEval (Union (CstInt 1) (Set [CstInt 2]))) @?= True
      ],
      testGroup "Without" [
        testCase "Basic without" $
          testEval (Without (Set [CstInt 1, CstInt 2, CstInt 3]) (Set [CstInt 2])) @?= Right (ValSet [ValInt 1, ValInt 3]),
        testCase "Without with second set being emptyset" $
          testEval (Without (Set [CstInt 1, CstInt 2, CstInt 3]) (Set [])) @?= Right (ValSet [ValInt 1, ValInt 2, ValInt 3]),
        testCase "Without with the same set" $
          testEval (Without (Set [CstInt 1, CstInt 2, CstInt 3]) (Set [CstInt 1, CstInt 2, CstInt 3])) @?= Right (ValSet []),
        testCase "Without where some elements are in second set but not in first set" $
          testEval (Without (Set [CstInt 1, CstInt 2]) (Set [CstInt 2, CstInt 3])) @?= Right (ValSet [ValInt 1]),
        testCase "Without where operand is not a set" $
          isLeft (testEval (Without (CstInt 1) (Set [CstInt 2]))) @?= True
      ],
      testGroup "Elem" [
        testCase "Element is in set" $
          testEval (Elem (CstInt 2) (Set [CstInt 1, CstInt 2, CstInt 3])) @?= Right (ValBool True),
        testCase "Element is not in set" $
          testEval (Elem (CstInt 4) (Set [CstInt 1, CstInt 2, CstInt 3])) @?= Right (ValBool False),
        testCase "Element in empty set" $
          testEval (Elem (CstInt 1) (Set [])) @?= Right (ValBool False),
        testCase "First operand is not a value" $
          isLeft (testEval (Elem (Div (CstInt 1) (CstInt 0)) (Set [CstInt 1]))) @?= True,
        testCase "Second operand is not a set" $
          isLeft (testEval (Elem (CstInt 1) (CstInt 2))) @?= True
      ]
    ]

taskBtests :: TestTree
taskBtests =
  testGroup
    "Task B"
    [
      testGroup "Set Construction" [
        parserTest "{}" (Set []),
        parserTest "{   }" (Set []),
        parserTest "{1}" (Set [CstInt 1]),
        parserTest "{1, 2  ,   3}" (Set [CstInt 1, CstInt 2, CstInt 3]),
        parserTestFail "{,}",
        parserTestFail "{1,}",
        parserTestFail "{,1}",
        parserTest "{1, true, {2, 3}}" (Set [CstInt 1, CstBool True, Set [CstInt 2, CstInt 3]]),
        -- No deduplication at parsing stage
        parserTest "{1, 2, 2, 3, 1}" (Set [CstInt 1, CstInt 2, CstInt 2, CstInt 3, CstInt 1])
      ],
      testGroup "Without and Union Operator" [
        parserTest "{1, 2, 3} without {2} " (Without (Set [CstInt 1, CstInt 2, CstInt 3]) (Set [CstInt 2])),
        parserTest "{1, 2} union {3, 4} " (Union (Set [CstInt 1, CstInt 2]) (Set [CstInt 3, CstInt 4])),
        -- right associativity
        parserTest "{1, 2, 3, 4} without {2} without {3} " (Without (Set [CstInt 1, CstInt 2, CstInt 3, CstInt 4]) (Without (Set [CstInt 2]) (Set [CstInt 3]))),
        parserTest "{1} union {2} union {3} " (Union (Set [CstInt 1]) (Union (Set [CstInt 2]) (Set [CstInt 3]))),
        -- lower precedence than "+" (evaluation of this exp leads to an error, but the parsing should still work)
        parserTest "1 + 2 without {2} " (Without (Add (CstInt 1) (CstInt 2)) (Set [CstInt 2])),
        parserTest "1 + 2 union {2} " (Union (Add (CstInt 1) (CstInt 2)) (Set [CstInt 2])),
        -- higher precedence than "=="
        parserTest "{1, 2} without {2} == {1} " (Eql (Without (Set [CstInt 1, CstInt 2]) (Set [CstInt 2])) (Set [CstInt 1])),
        parserTest "{1} union {2} == {1, 2} " (Eql (Union (Set [CstInt 1]) (Set [CstInt 2])) (Set [CstInt 1, CstInt 2]))
      ],
      testGroup "Elem Operator" [
        parserTest "2 elem {1, 2, 3} " (Elem (CstInt 2) (Set [CstInt 1, CstInt 2, CstInt 3])),
        parserTest "true elem {false, true} " (Elem (CstBool True) (Set [CstBool False, CstBool True])),
        -- left associativity
        parserTest "2 elem {1, 2} elem {true, false} " (Elem (Elem (CstInt 2) (Set [CstInt 1, CstInt 2])) (Set [CstBool True, CstBool False])),
        -- higher precedence than "=="
        parserTest "2 elem {1, 2, 3} == true " (Eql (Elem (CstInt 2) (Set [CstInt 1, CstInt 2, CstInt 3])) (CstBool True)),
        -- lower precedence than "without" and "union"
        parserTest "2 elem {1, 2, 3} without {2} " (Elem (CstInt 2) (Without (Set [CstInt 1, CstInt 2, CstInt 3]) (Set [CstInt 2]))),
        parserTest "3 elem {1, 2} union {3} " (Elem (CstInt 3) (Union (Set [CstInt 1, CstInt 2]) (Set [CstInt 3])))
      ]
    ]

taskCtests :: TestTree
taskCtests =
  testGroup
    "Task C"
    [ 
      testCase "Smoothen(0)" $ testEquivalence smoothen 0,
      testCase "Smoothen(1)" $ testEquivalence smoothen 1,
      testCase "Smoothen(2)" $ testEquivalence smoothen 2,
      testCase "Smoothen(25)" $ testEquivalence smoothen 25,
      testCase "Galapagos(0)" $ testEquivalence (Galapagos.galapagos 0 defaultConfig) 0,
      testCase "Galapagos(1)" $ testEquivalence (Galapagos.galapagos 0 defaultConfig) 1,
      testCase "Galapagos(2)" $ testEquivalence (Galapagos.galapagos 0 defaultConfig) 2,
      testCase "Galapagos(25)" $ testEquivalence (Galapagos.galapagos 0 defaultConfig) 25
    ]

--------------------------- Helpers for Task D tests ---------------------------

assertSuccessfulMeeting :: Galapagos.Params -> (Galapagos.Finch, Galapagos.Finch) -> (Int, Int) -> IO ()
assertSuccessfulMeeting params (finchA, finchB) (expectedHPA, expectedHPB) =
  let (mFinchA, mFinchB) = Galapagos.meet params (finchA, finchB)
  in
    case (mFinchA, mFinchB) of
      (Just finchA', Just finchB') -> do
          Galapagos.finchHP finchA' @?= expectedHPA
          Galapagos.finchHP finchB' @?= expectedHPB
      _ -> assertFailure "Both finches should survive"

--------------------------- Task D tests ---------------------------

taskDtests :: TestTree
taskDtests =
  testGroup
    "Task D"
    [
      testGroup "Simple successful meets" [
        testCase "Samaritan - Samaritan" $
        let (expectedPayoff, _,_,_) = Galapagos.payoffs Galapagos.defaultParams
        in
          assertSuccessfulMeeting Galapagos.defaultParams (samaritan, samaritan) (Galapagos.finchHP samaritan + expectedPayoff, 
                                                                                  Galapagos.finchHP samaritan + expectedPayoff),
        testCase "Cheater - Cheater" $
        let (_, expectedPenalty, _, _) = Galapagos.payoffs Galapagos.defaultParams
        in
          assertSuccessfulMeeting Galapagos.defaultParams (cheater, cheater) (Galapagos.finchHP cheater + expectedPenalty, 
                                                                              Galapagos.finchHP cheater + expectedPenalty),
        testCase "Samaritan - Cheater" $
        let (_, _, expectedPayoffCheater, expectedPayoffSamaritan) = Galapagos.payoffs Galapagos.defaultParams
        in
          assertSuccessfulMeeting Galapagos.defaultParams (samaritan, cheater) (Galapagos.finchHP samaritan + expectedPayoffSamaritan, 
                                                                                Galapagos.finchHP cheater + expectedPayoffCheater),
        testCase "Cheater - Samaritan" $
        let (_, _, expectedPayoffCheater, expectedPayoffSamaritan) = Galapagos.payoffs Galapagos.defaultParams
        in
          assertSuccessfulMeeting Galapagos.defaultParams (cheater, samaritan) (Galapagos.finchHP cheater + expectedPayoffCheater, 
                                                                                Galapagos.finchHP samaritan + expectedPayoffSamaritan),
        testCase "MaxHP can not be exceeded" $
        let params = Galapagos.defaultParams { Galapagos.maxHP = Galapagos.finchHP samaritan }
        in
          assertSuccessfulMeeting params (samaritan, samaritan) (Galapagos.finchHP samaritan, 
                                                                Galapagos.finchHP samaritan)
      ],

      testGroup "Invalid meets" [
        testCase "Invalid - Samaritan" $
        let (mFinchA, mFinchB) = Galapagos.meet Galapagos.defaultParams (invalid, samaritan) 
        in
          case (mFinchA, mFinchB) of
            (Nothing, Just _) -> pure ()
            _ -> assertFailure "Invalid finch should be removed, samaritan should survive",
        testCase "Invalid - Invalid" $
        let (mFinchA, mFinchB) = Galapagos.meet Galapagos.defaultParams (invalid, invalid) 
        in
          case (mFinchA, mFinchB) of
            (Nothing, Nothing) -> pure ()
            _ -> assertFailure "Both finches should be removed",
        testCase "Valid MeetOp, invalid interaction" $
        let (mFinchA, mFinchB) = Galapagos.meet Galapagos.defaultParams (invalidInteraction, samaritan) 
        in
          case (mFinchA, mFinchB) of
            (Nothing, Just _) -> pure ()
            _ -> assertFailure "Finch with invalid interaction should be removed, samaritan should survive"
      ],

      testGroup "Multiple meets (strategy updates)" [
        testCase "Samaritan - Samaritan, two meets" $
        let (mFinchA1, mFinchB1) = Galapagos.meet Galapagos.defaultParams (samaritan, samaritan) 
        in
          case (mFinchA1, mFinchB1) of
            (Just finchA1, Just finchB1) ->
              let (expectedPayoff, _,_,_) = Galapagos.payoffs Galapagos.defaultParams
              in
                assertSuccessfulMeeting Galapagos.defaultParams (finchA1, finchB1) 
                                        (Galapagos.finchHP samaritan + 2 * expectedPayoff, Galapagos.finchHP samaritan + 2 * expectedPayoff)
            _ -> assertFailure "Both finches should survive first meet",
        testCase "Flipflop - Samaritan, two meets" $
        let (mFinchA1, mFinchB1) = Galapagos.meet Galapagos.defaultParams (flipflop, samaritan) 
        in
          case (mFinchA1, mFinchB1) of
            (Just finchA1, Just finchB1) ->
              let (expectedPayoffBothSamaritan, _, expectedPayoffCheater, expectedPayoffSamaritan) = Galapagos.payoffs Galapagos.defaultParams
              in
                assertSuccessfulMeeting Galapagos.defaultParams (finchA1, finchB1) 
                                        (Galapagos.finchHP flipflop + expectedPayoffBothSamaritan + expectedPayoffCheater,
                                         Galapagos.finchHP samaritan + expectedPayoffBothSamaritan + expectedPayoffSamaritan)
            _ -> assertFailure "Both finches should survive first meet",
        -- meeting with invalid finch does not update strategy
          -- flipflop1 meets invalid
          -- flipflop2 is just basic flipflop
          -- each meets samaritan -> result should be the same
        testCase "meeting with invalid finch does not update strategy" $
        let (mFinchA1, _mFinchB1) = Galapagos.meet Galapagos.defaultParams (flipflop, invalid) 
        in
            case mFinchA1 of
                Just finchA1 ->
                  let flipflopAfterInvalid = finchA1 { Galapagos.finchStrategy = Galapagos.finchStrategy flipflop }
                      (mFf1, mSm1) = Galapagos.meet Galapagos.defaultParams (flipflopAfterInvalid, samaritan)
                      (mFf2, mSm2) = Galapagos.meet Galapagos.defaultParams (flipflop, samaritan)
                  in
                    case (mFf1, mSm1, mFf2, mSm2) of
                      (Just ff1, Just sm1, Just ff2, Just sm2) -> do
                            Galapagos.finchHP ff1 @?= Galapagos.finchHP ff2
                            Galapagos.finchHP sm1 @?= Galapagos.finchHP sm2
                      _ -> assertFailure "All finches should survive second meet"
                _ -> assertFailure "Flipflop should survive meeting with invalid finch"
      ]
    ]


--------------------------- Helpers for Task E tests ---------------------------
samaritanStrategyString :: String
samaritanStrategyString = " strategy samaritan #ff0000 { loop x = 0 for i < 100 do let unused = meet in groom } "
samaritanStrategy :: ( String, Galapagos.Colour, Exp )
samaritanStrategy = ( "samaritan",
                      Galapagos.RGB 0xff 0x00 0x00,
                      ForLoop
                        ("x", CstInt 0)
                        ("i", CstInt 100)
                        (Let "unused" Meet Groom)
                    )

whStrings :: [String]
whStrings = ["height = 10 ", "width = 20 "]

paramStrings :: [String]
paramStrings =
  [ "startHP = 10 ",
    "invReproductionChance = 1 ",
    "maxHP = 100 ",
    "lifespan = 25 ",
    "invDensity = 12 ",
    "payoffs = (4, 3, 2, 1) "
  ]

parsedCfg :: Galapagos.Config
parsedCfg = Galapagos.Config
  { Galapagos.cfgHeight = 10,
    Galapagos.cfgWidth = 20,
    Galapagos.cfgParams = Galapagos.Params { Galapagos.startHP = 10,
                                  Galapagos.invReproductionChance = 1,
                                  Galapagos.maxHP = 100,
                                  Galapagos.lifespan = 25,
                                  Galapagos.invDensity = 12,
                                  Galapagos.payoffs = (4, 3, 2, 1)
                                },
    Galapagos.cfgStrategies = []
  }

genArbitraryOrderInputString :: Gen String
genArbitraryOrderInputString = do
  wh <- concat <$> shuffle whStrings
  params <- concat <$> shuffle paramStrings
  pure (wh ++ params)

-------------------------------------------------------------------------------

taskEtests :: TestTree
taskEtests =
  testGroup
    "Task E"
    [
      testGroup "Basic successful parsing" [
        galapagosParserTest "height = 10 width =20" 
        (Galapagos.Config { Galapagos.cfgHeight = 10, Galapagos.cfgWidth = 20, Galapagos.cfgParams = Galapagos.defaultParams, Galapagos.cfgStrategies = [] }),
        galapagosParserTest "height=10 width=20 startHP=10 invReproductionChance=1"
        (Galapagos.Config { Galapagos.cfgHeight = 10, Galapagos.cfgWidth = 20, Galapagos.cfgParams = Galapagos.defaultParams { Galapagos.startHP = 10, Galapagos.invReproductionChance = 1 }, Galapagos.cfgStrategies = [] }),
        galapagosParserTest "height=10 width=20 payoffs=(4, 3, 2, 1)" 
        (Galapagos.Config { Galapagos.cfgHeight = 10, Galapagos.cfgWidth = 20, Galapagos.cfgParams = Galapagos.defaultParams { Galapagos.payoffs = (4, 3, 2, 1) }, Galapagos.cfgStrategies = [] }),
        -- negative numbers supported
        galapagosParserTest "height=10 width=20 payoffs=(4, -3, 2, -1)" 
        (Galapagos.Config { Galapagos.cfgHeight = 10, Galapagos.cfgWidth = 20, Galapagos.cfgParams = Galapagos.defaultParams { Galapagos.payoffs = (4, -3, 2, -1) }, Galapagos.cfgStrategies = [] }),
        -- multiple mentions of same param overwrite
        galapagosParserTest "height=10 width=20 invDensity=5 invDensity=7"
        (Galapagos.Config { Galapagos.cfgHeight = 10, Galapagos.cfgWidth = 20, Galapagos.cfgParams = Galapagos.defaultParams { Galapagos.invDensity = 7 }, Galapagos.cfgStrategies = [] }),

        -- can parse strategy
        galapagosParserTest ("height=10 width=20 " ++ samaritanStrategyString)
        (Galapagos.Config { Galapagos.cfgHeight = 10, Galapagos.cfgWidth = 20, Galapagos.cfgParams = Galapagos.defaultParams, Galapagos.cfgStrategies = 
          [ samaritanStrategy ] }),

        -- multiple strategies
        galapagosParserTest ("height=10 width=20 strategy cheater #0000ff { loop x = 0 for i < 100 do let unused = meet in ignore } " ++ samaritanStrategyString)
        (Galapagos.Config { Galapagos.cfgHeight = 10, Galapagos.cfgWidth = 20, Galapagos.cfgParams = Galapagos.defaultParams, Galapagos.cfgStrategies = 
          [ 
            samaritanStrategy,
            ( "cheater",
              Galapagos.RGB 0x00 0x00 0xff,
              ForLoop
                ("x", CstInt 0)
                ("i", CstInt 100)
                (Let "unused" Meet Ignore)
            )
          ] }),
        -- apl keywords are valid strategy names
        galapagosParserTest "height=10 width=20 strategy for #ff0000 { loop x = 0 for i < 100 do let unused = meet in groom }"
        (Galapagos.Config { Galapagos.cfgHeight = 10, Galapagos.cfgWidth = 20, Galapagos.cfgParams = Galapagos.defaultParams, Galapagos.cfgStrategies = 
          [ ( "for",
              Galapagos.RGB 0xff 0x00 0x00,
              ForLoop
                ("x", CstInt 0)
                ("i", CstInt 100)
                (Let "unused" Meet Groom)
            )
          ] }),
        -- strategy names are allowed to contain letters, numbers, -, _ and .
        galapagosParserTest "height=10 width=20 strategy _samaritan-2_0.v1 #ff0000 { loop x = 0 for i < 100 do let unused = meet in groom }"
        (Galapagos.Config { Galapagos.cfgHeight = 10, Galapagos.cfgWidth = 20, Galapagos.cfgParams = Galapagos.defaultParams, Galapagos.cfgStrategies = 
          [ ( "_samaritan-2_0.v1",
              Galapagos.RGB 0xff 0x00 0x00,
              ForLoop
                ("x", CstInt 0)
                ("i", CstInt 100)
                (Let "unused" Meet Groom)
            )
          ] })
      ],
      testGroup "Invalid inputs" [
        galapagosParserTestFail "height = 10 width = 20 height = 10",
        galapagosParserTestFail "height = 10",
        -- explicit + sign not supported
        galapagosParserTestFail "height=+10 width=20",
        galapagosParserTestFail "height = 10",
        -- decimals not supported
        galapagosParserTestFail "height=10 width=20 invDensity=5.5",
        -- payoff requires exactly 4 numbers
        galapagosParserTestFail "height=10 width=20 payoffs=(4, -3, 2)",
        -- invalid param name fails
        galapagosParserTestFail "height=10 width=20 invalidParam=5",
        -- strategy with name which is keyword fails
        galapagosParserTestFail "height=10 width=20 strategy height #ff0000 { loop x = 0 for i < 100 do let unused = meet in groom }",
        -- strategy with name including any special character (other than - _ .) fails
        galapagosParserTestFail "height=10 width=20 strategy <invalid-name> #ff0000 { loop x = 0 for i < 100 do let unused = meet in groom }",
        -- invalid color hex-string fails
        galapagosParserTestFail "height=10 width=20 strategy samaritan #ff00gg { loop x = 0 for i < 100 do let unused = meet in groom }",
        galapagosParserTestFail "height=10 width=20 strategy samaritan #ff00 { loop x = 0 for i < 100 do let unused = meet in groom }",
        galapagosParserTestFail "height=10 width=20 strategy samaritan #ff00000 { loop x = 0 for i < 100 do let unused = meet in groom }"
      ],

      testGroup "Ordering" [
        -- w-h needs to come before params
        galapagosParserTestFail "startHP=10 invReproductionChance=1 height=10 width=20",
        -- specifying w-h again after params fails
        galapagosParserTestFail "height=10 width=20 startHP=10 invReproductionChance=1 height=15",
        -- param needs to come before strategy
        galapagosParserTestFail "height=10 width=20 strategy samaritan #ff0000 { for i = 0 to 100 { let unused = meet groom } } startHP=10",

        ------------ arbitrary-order tests -------
        testCase "Arbitrary Order Parsing" $ do
          samples <- replicateM 10 (generate genArbitraryOrderInputString)
          forM_ samples $ \s ->
            case parseGalapagos "input" s of
            Left err -> assertFailure err
            Right e' -> e' @?= parsedCfg
      ]
    ]

---------------------------Helpers for Task F tests ---------------------------

-- ANSI escapes for 24-bit background/foreground
bgCode :: Galapagos.Colour -> String
bgCode (Galapagos.RGB r g b) =
  "\ESC[48;2;" <> show r <> ";" <> show g <> ";" <> show b <> "m"

fgCode :: Galapagos.Colour -> String
fgCode (Galapagos.RGB r g b) =
  "\ESC[38;2;" <> show r <> ";" <> show g <> ";" <> show b <> "m"

-- Reset attributes
reset :: String
reset = "\ESC[0m"

-- Render a single "pixel cell" using ▀
renderPixelCell :: Galapagos.Colour -> Galapagos.Colour -> String
renderPixelCell top bottom =
  fgCode top <> bgCode bottom <> "▀" <> reset

-- Render a row of cells from two color rows
renderRow :: [Galapagos.Colour] -> [Galapagos.Colour] -> String
renderRow tops bottoms = concat (zipWith renderPixelCell tops bottoms) <> "\n"

-- Render the whole grid (height must be even)
renderGrid :: [[Galapagos.Colour]] -> String
renderGrid [] = ""
renderGrid (a : b : rest) = renderRow a b <> renderGrid rest
renderGrid [_] = error "Grid height must be an even number."


printGalapagos :: (Int, Int) -> Int -> IO()
printGalapagos (h, w) steps = do
  let cfg = defaultConfig {Galapagos.cfgHeight = h, Galapagos.cfgWidth = w}
      rules = Galapagos.galapagos 0 cfg
  s <- startAutomaton rules h w
  replicateM_ steps $ stepAutomaton s
  grid <- observeAutomaton s
  putStrLn $ "After " ++ show steps ++ " steps:"
  putStrLn $ renderGrid grid

--------------------------- Task F tests ---------------------------

taskFtests :: TestTree
taskFtests =
  testGroup
    "Task F"
    [
      testCase "Galapagos 0" $ printGalapagos (10, 10) 0,
      testCase "Galapagos 1" $ printGalapagos (10, 10) 1,
      testCase "Galapagos 2" $ printGalapagos (10, 10) 2,
      testCase "Galapagos 3" $ printGalapagos (10, 10) 3,
      testCase "Galapagos 4" $ printGalapagos (10, 10) 4,
      testCase "Galapagos 5" $ printGalapagos (10, 10) 5
    ]

tests :: TestTree
tests =
  testGroup
    "All tests"
    [ taskAtests,
      taskBtests,
      taskCtests,
      taskDtests,
      taskEtests,
      taskFtests
    ]


